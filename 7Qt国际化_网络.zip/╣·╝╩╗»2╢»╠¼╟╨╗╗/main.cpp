#include <QApplication>
#include <QtGui>
class Dialog : public QWidget
{
        Q_OBJECT
public:
        Dialog(QWidget *parent = 0);
private:
        QLabel *label;
        QPushButton *okButton;
        int flag;

private slots:
        void retranslateStrings();
        void switchLang();
};

Dialog::Dialog(QWidget *parent)
    : QWidget(parent)
{
    label = new QLabel;
    okButton = new QPushButton;
    connect(okButton, SIGNAL(clicked()), this, SLOT(switchLang()));
    flag = 0;
    retranslateStrings();

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout->addWidget(label);
    mainLayout->addWidget(okButton);
    setLayout(mainLayout);
}

//tr()��ص����
void Dialog::retranslateStrings()
{
    label->setText(tr("Name:"));
    okButton->setText(tr("Switch Language"));
    setWindowTitle(tr("Switch Language ..."));
}

//�л�����
void Dialog::switchLang()
{
    QTranslator translator;
    if (0==flag) {
        translator.load("zh_lang");
        flag=1;
    } else {
	     translator.load("jp_lang");
        flag=0;
    }
	//���translatorδ����load���ط����ļ�
	//���ַ������Ǳ��ʱ��Ĭ���ַ���
    QApplication::instance()->installTranslator(&translator);
    retranslateStrings();
}

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    Dialog dialog;
    dialog.show();
    return app.exec();
}

#include "main.moc"
