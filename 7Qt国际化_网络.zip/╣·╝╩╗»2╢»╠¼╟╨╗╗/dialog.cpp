#include <QtGui>
#include "dialog.h"

Dialog::Dialog(QWidget *parent)
    : QDialog(parent)
{
    label = new QLabel;
    okButton = new QPushButton;
    connect(okButton, SIGNAL(clicked()), this, SLOT(switchLang()));
    flag = 0;
    retranslateStrings();

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout->addWidget(label);
    mainLayout->addWidget(okButton);
    setLayout(mainLayout);
}

//tr()��ص����
void Dialog::retranslateStrings()
{
    label->setText(tr("Name:"));
    okButton->setText(tr("Switch Language"));
    setWindowTitle(tr("Switch Language ..."));
}

//�л�����
void Dialog::switchLang()
{
    QTranslator translator;
    if (0==flag) {
        translator.load("switchlang_zh");
        flag=1;
    } else {
        flag=0;
    }
	//���translatorδ����load���ط����ļ�
	//���ַ�����ʾ���ʱ��Ĭ���ַ���
    QApplication::instance()->installTranslator(&translator);
    retranslateStrings();
}

