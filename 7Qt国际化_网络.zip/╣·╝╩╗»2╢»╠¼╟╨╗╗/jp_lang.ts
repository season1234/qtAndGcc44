<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="zh_CN">
<context>
    <name>Dialog</name>
    <message>
        <location filename="main.cpp" line="36"/>
        <source>Name:</source>
        <translation>名：</translation>
    </message>
    <message>
        <location filename="main.cpp" line="37"/>
        <source>Switch Language</source>
        <translation>言語を切り替える</translation>
    </message>
    <message>
        <location filename="main.cpp" line="38"/>
        <source>Switch Language ...</source>
        <translation>言語を切り替える...</translation>
    </message>
</context>
</TS>
