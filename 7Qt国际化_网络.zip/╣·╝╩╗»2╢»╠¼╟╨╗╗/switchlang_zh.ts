<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="zh_CN">
<context>
    <name>Dialog</name>
    <message>
        <location filename="dialog.cpp" line="22"/>
        <source>Name:</source>
        <translation>姓名：</translation>
    </message>
    <message>
        <location filename="dialog.cpp" line="23"/>
        <source>Switch Language</source>
        <translation>更换语言</translation>
    </message>
    <message>
        <location filename="dialog.cpp" line="24"/>
        <source>Switch Language ...</source>
        <translation>更换语言...</translation>
    </message>
</context>
</TS>
