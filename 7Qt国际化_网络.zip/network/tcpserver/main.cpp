#include <QApplication>
#include <QtGui>
#include <QtCore>
#include <iostream>
#include <cstring>
#include <QtNetwork>
using namespace std;

class ServerWin : public QWidget
{
	Q_OBJECT
public:
	ServerWin(const qint16 port)
	{
		QVBoxLayout *vLayout = new QVBoxLayout(this);
	    ptext = new QPlainTextEdit(this);
		ptext->setReadOnly(true);
		pInput = new QPlainTextEdit(this);
		pbtn = new QPushButton("Send", this);
		vLayout->addWidget(ptext);
		vLayout->addWidget(pInput);
		vLayout->addWidget(pbtn);
		pserver = new QTcpServer(this);
		connect(pserver, SIGNAL(newConnection()), this, SLOT(acceptSlot()));
		pserver->listen(QHostAddress::Any, port);
	}
protected:
    QPlainTextEdit* ptext;
	QPlainTextEdit* pInput;
	QPushButton* pbtn;
	QTcpServer* pserver;
	QTcpSocket* ppeer;
protected:
    void closeEvent(QCloseEvent *event);
protected slots:
    void sendata();
	void readata();
	void acceptSlot();
	void onWritten(qint64 bytes);
	void disconnectedSlot();
	void stateSlot(QAbstractSocket::SocketError socketError = (QAbstractSocket::SocketError)-1);
};

void ServerWin::closeEvent(QCloseEvent *event)
{
	ppeer->disconnectFromHost();
}

void ServerWin::acceptSlot()
{
	ppeer = pserver->nextPendingConnection();

	connect(ppeer, SIGNAL(readyRead()), this, SLOT(readata()));
	connect(ppeer, SIGNAL(bytesWritten(qint64)), this, SLOT(onWritten(qint64)));
	connect(ppeer, SIGNAL(disconnected()), this, SLOT(disconnectedSlot()));
	connect(ppeer, SIGNAL(error(QAbstractSocket::SocketError)), this, 
																SLOT(stateSlot(QAbstractSocket::SocketError)));
																
	QString sendText = QString("New Connection %1").arg((ppeer->peerAddress()).toString()) ;
	ptext->appendPlainText(sendText);
	connect(pbtn, SIGNAL(clicked()), this, SLOT(sendata()));
}

void ServerWin::sendata()
{
	QString data = pInput->toPlainText();
	if(!data.isEmpty())
	{
		char buf[(data.toStdString()).length() + 1];
		sprintf(buf, "%s", (data.toStdString()).c_str());
		ppeer->write(buf, strlen(buf)+1);
	}
}

void ServerWin::readata()
{
	if(ppeer->bytesAvailable() > 0)
	{
		char buf[ppeer->bytesAvailable()];
		memset(buf, 0, ppeer->bytesAvailable());
		ppeer->read(buf, ppeer->bytesAvailable());
		QString recvText(trUtf8(buf));
		ptext->appendPlainText(recvText);
		//ptext->appendPlainText("\n");
	}
}

void ServerWin::onWritten(qint64 bytes)
{
	QString sendText = QString("send %1 bytes to %2").arg(bytes)
																							.arg((ppeer->peerAddress()).toString()) ;
	pInput->clear();
	ptext->appendPlainText(sendText);
}

void ServerWin::disconnectedSlot()
{
	ptext->appendPlainText("Disconnected!");
	qDebug() << "Disconnected!";
}

void ServerWin::stateSlot(QAbstractSocket::SocketError socketError)
{
	switch (socketError)
	{
		case QAbstractSocket::RemoteHostClosedError:
			ptext->appendPlainText("RemoteHostClosedError.");
			break;
		case QAbstractSocket::HostNotFoundError:
		    ptext->appendPlainText("HostNotFoundError.");
			break;
		case QAbstractSocket::ConnectionRefusedError:
		    ptext->appendPlainText("ConnectionRefusedError.");
			break;
		default:
		    ptext->appendPlainText("OtherError.");
	}
}

int main(int argc, char* argv[])
{
	QApplication app(argc, argv);
	ServerWin win(8808);
	win.show();
	return app.exec();
}

#include "main.moc"
