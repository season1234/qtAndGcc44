#include <QApplication>
#include <QtGui>
#include <QtCore>
#include <iostream>
#include <cstring>
#include <QtNetwork>
using namespace std;

class UdpWin : public QWidget
{
	Q_OBJECT
public:
	UdpWin(const quint16 listenPort)
	{
		QVBoxLayout *vLayout = new QVBoxLayout(this);
		QHBoxLayout* hLayout = new QHBoxLayout;
		pRemoteIP = new QLineEdit(this);
		pRemotePort = new QLineEdit(this);
		hLayout->addWidget(pRemoteIP);
		hLayout->addWidget(pRemotePort);
		vLayout->addLayout(hLayout);
	    ptext = new QPlainTextEdit(this);
		ptext->setReadOnly(true);
		pInput = new QPlainTextEdit(this);
		pbtn = new QPushButton("Send", this);
		vLayout->addWidget(ptext);
		vLayout->addWidget(pInput);
		vLayout->addWidget(pbtn);
		connect(pbtn, SIGNAL(clicked()), this, SLOT(sendata()));
		uServer = new QUdpSocket(this);
        connect(uServer, SIGNAL(readyRead()), this, SLOT(readata()));
		connect(uServer, SIGNAL(bytesWritten(qint64)), this, SLOT(onWritten(qint64)));
		connect(uServer, SIGNAL(error(QAbstractSocket::SocketError)), this, 
																SLOT(stateSlot(QAbstractSocket::SocketError)));
		uServer->bind(QHostAddress::Any, listenPort);
	    ptext->appendPlainText(QString("UDP Listening at %1 ...").arg(listenPort));
		//uServer->joinMulticastGroup(QHostAddress ("239.255.43.21"));
	}
	~UdpWin()
	{
		//uServer->leaveMulticastGroup(QHostAddress ("239.255.43.21"));
	}
protected:
    QLineEdit* pRemoteIP;
	QLineEdit* pRemotePort;
    QPlainTextEdit* ptext;
	QPlainTextEdit* pInput;
	QPushButton* pbtn;
	QUdpSocket* uServer;
protected slots:
    void sendata();
	void readata();
	void onWritten(qint64 bytes);
	void stateSlot(QAbstractSocket::SocketError socketError = (QAbstractSocket::SocketError)-1);
};

void UdpWin::sendata()
{
	QString data = pInput->toPlainText();
	if(!data.isEmpty())
	{
		char buf[(data.toStdString()).length() + 1];
		sprintf(buf, "%s", (data.toStdString()).c_str());
		uServer->writeDatagram(buf, strlen(buf)+1, QHostAddress(pRemoteIP->text()), 
		                                                   (pRemotePort->text()).toUShort());
	}
}

void UdpWin::onWritten(qint64 bytes)
{
	QString sendText = QString("send %1 bytes to %2").arg(bytes)
																						.arg(pRemoteIP->text()) ;
	pInput->clear();
	ptext->appendPlainText(sendText);
}

void UdpWin::readata()
{
	qDebug()<<__LINE__<<__func__<<uServer->pendingDatagramSize();
	if(uServer->pendingDatagramSize() > 0)
	{
		char buf[uServer->pendingDatagramSize()];
		memset(buf, 0, uServer->pendingDatagramSize());
		QHostAddress rHost;
		quint16 rPort;
		uServer->readDatagram(buf, uServer->pendingDatagramSize(), &rHost, &rPort);
		QString recvText = QString("[%1] %2").arg(rHost.toString()).arg(buf);
		ptext->appendPlainText(recvText);
	}
}

void UdpWin::stateSlot(QAbstractSocket::SocketError socketError)
{
	switch (socketError)
	{
		case QAbstractSocket::RemoteHostClosedError:
			ptext->appendPlainText("RemoteHostClosedError.");
			break;
		case QAbstractSocket::HostNotFoundError:
		    ptext->appendPlainText("HostNotFoundError.");
			break;
		case QAbstractSocket::ConnectionRefusedError:
		    ptext->appendPlainText("ConnectionRefusedError.");
			break;
		default:
		    ptext->appendPlainText("OtherError.");
	}
}

int main(int argc, char* argv[])
{
	QApplication app(argc, argv);
	UdpWin win(9901);
	win.show();
	return app.exec();
}

#include "main.moc"
