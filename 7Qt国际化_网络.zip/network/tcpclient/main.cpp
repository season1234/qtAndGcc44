#include <QApplication>
#include <QtGui>
#include <QtCore>
#include <iostream>
#include <cstring>
#include <QtNetwork>
using namespace std;

class MyWin : public QWidget
{
	Q_OBJECT
public:
	MyWin(const QString & IP, const qint16 port)
	{
		QVBoxLayout *vLayout = new QVBoxLayout(this);
	    ptext = new QPlainTextEdit;
		ptext->setReadOnly(true);
		pInput = new QPlainTextEdit;
		pbtn = new QPushButton("Send");
		vLayout->addWidget(ptext);
		vLayout->addWidget(pInput);
		vLayout->addWidget(pbtn);
		pclient = new QTcpSocket(this);
		connect(pclient, SIGNAL(readyRead()), this, SLOT(readata()));
		connect(pclient, SIGNAL(bytesWritten(qint64)), this, SLOT(onWritten(qint64)));
		connect(pclient, SIGNAL(hostFound()), this, SLOT(hostFoundSlot()));
		connect(pclient, SIGNAL(connected()), this, SLOT(connectedSlot()));
		connect(pclient, SIGNAL(disconnected()), this, SLOT(disconnectedSlot()));
		connect(pclient, SIGNAL(error(QAbstractSocket::SocketError)), this, SLOT(stateSlot(QAbstractSocket::SocketError)));
		
		pclient->connectToHost (IP, port);
		connect(pbtn, SIGNAL(clicked()), this, SLOT(sendata()));
	}
protected:
    QPlainTextEdit* ptext;
	QPlainTextEdit* pInput;
	QPushButton* pbtn;
	QTcpSocket* pclient;
protected:
    void closeEvent(QCloseEvent *event);
protected slots:
    void sendata();
	void readata();
	void onWritten(qint64 bytes);
	void hostFoundSlot();
	void connectedSlot();
	void disconnectedSlot();
	void stateSlot(QAbstractSocket::SocketError socketError = (QAbstractSocket::SocketError)-1);
};
void MyWin::sendata()
{
	QString data = pInput->toPlainText();
	if(!data.isEmpty())
	{
		char buf[(data.toStdString()).length() + 1];
		sprintf(buf, "%s", (data.toStdString()).c_str());
		pclient->write(buf, strlen(buf)+1);
	}
}

void MyWin::closeEvent(QCloseEvent *event)
{
	pclient->disconnectFromHost();
}

void MyWin::readata()
{
	if(pclient->bytesAvailable() > 0)
	{
		char buf[pclient->bytesAvailable()];
		memset(buf, 0, pclient->bytesAvailable());
		pclient->read(buf, pclient->bytesAvailable());
		QString recvText(trUtf8(buf));
		ptext->appendPlainText(recvText);
	}
}

void MyWin::onWritten(qint64 bytes)
{
	QString sendText = QString("send %1 bytes to %2").arg(bytes)
																							.arg((pclient->peerAddress()).toString()) ;
	pInput->clear();
	ptext->appendPlainText(sendText);
}
void MyWin::hostFoundSlot()
{
	ptext->appendPlainText("HostFound!");
}

void MyWin::connectedSlot()
{
	ptext->appendPlainText("Connected!");
}

void MyWin::disconnectedSlot()
{
	ptext->appendPlainText("Disconnected!");
	qDebug() << "Disconnected!";
}

void MyWin::stateSlot(QAbstractSocket::SocketError socketError)
{
	switch (socketError)
	{
		case QAbstractSocket::RemoteHostClosedError:
			ptext->appendPlainText("RemoteHostClosedError.");
			break;
		case QAbstractSocket::HostNotFoundError:
		    ptext->appendPlainText("HostNotFoundError.");
			break;
		case QAbstractSocket::ConnectionRefusedError:
		    ptext->appendPlainText("ConnectionRefusedError.");
			break;
		default:
		    ptext->appendPlainText("OtherError.");
	}
}

int main(int argc, char* argv[])
{
	QApplication app(argc, argv);
	MyWin win("127.0.0.1", 8808);
	win.show();
	return app.exec();
}

#include "main.moc"
