#include "Decoder.h"

Decoder::Decoder() : nframe(0)
{
	//��ʼ��������
	/* must be called before using avcodec lib */
    avcodec_init();
    /* register all the codecs */
    avcodec_register_all();
	codec = avcodec_find_decoder(CODEC_ID_MPEG2VIDEO);
	codec_context = avcodec_alloc_context();
    out_frame = avcodec_alloc_frame();
	picture = avcodec_alloc_frame();
	if(codec->capabilities&CODEC_CAP_TRUNCATED)
        codec_context->flags|= CODEC_FLAG_TRUNCATED; /* we do not send complete frames */
	/* For some codecs, such as msmpeg4 and mpeg4, width and height
       MUST be initialized there because this information is not
       available in the bitstream. */
    /* open it */
    if (avcodec_open(codec_context, codec) < 0) {
        cerr << "avcodec_open() failed" << endl;
    }
    rgb_buf = new char[640*480*4];
	//תΪrgb32Ŀ�����ݽṹ
	picture->data[0] = (uint8_t *) rgb_buf;
	picture->data[1] = NULL;
	picture->data[2] = NULL;
	picture->linesize[0] = 640 * 4;
	picture->linesize[1] = 0;
	picture->linesize[2] = 0;
	//YUV420ת��ΪRGBA32�����ṹ
	img_convert_ctx = sws_getContext(640, 480, PIX_FMT_YUV420P, 
									640, 480, PIX_FMT_RGB32, SWS_BICUBIC, NULL, NULL, NULL);												
}

Decoder::~Decoder()
{
    delete []rgb_buf;
	av_free(out_frame);
	av_free(picture);
}

void Decoder::decode(char* inbuf, unsigned int dataSize)
{
   int got_picture, len;
   char* inbuf_ptr = inbuf;
	//����������
	while (dataSize > 0) 
	{
        len = avcodec_decode_video(codec_context, out_frame, &got_picture,
                                       (const uint8_t*)inbuf_ptr, dataSize);
        //len ���õ������뻺���е�����
        if (len < 0)
               cerr<< "Error while decoding frame "<< nframe << endl;
        if (got_picture) {
	             //��ɫ�ռ�ת��, ����֮�⻹������С�ͷŴ�ͼ��
	            sws_scale(img_convert_ctx, out_frame->data, out_frame->linesize, 
								0, 480, picture->data, picture->linesize);	
                /* the picture is allocated by the decoder. no need to free it */
				pixmap.fromImage(QImage(picture->data[0], 640, 480, QImage::Format_ARGB32_Premultiplied));
				nframe++;
				emit picture_decoded(pixmap);
        }
        dataSize -= len;
        inbuf_ptr += len;
    }
}
