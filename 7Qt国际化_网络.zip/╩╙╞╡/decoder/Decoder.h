#ifndef RECEIVER_H
#define RECEIVER_H

extern "C" {
#include "avcodec.h"
#include "swscale.h"
#include "avformat.h"
}
#include <QtCore>
#include <QPixmap>
#include <QImage>
#include <iostream>
using namespace std;

class Decoder : QObject
{
    Q_OBJECT
public:
    Decoder();
	~Decoder();
	void decode(char* inbuf, unsigned int dataSize);
signals:
	void picture_decoded(QPixmap & pixmap);
private:
    AVCodec *codec;
	AVCodecContext *codec_context;
	AVFrame *out_frame;
	AVFrame *picture;
	struct SwsContext *img_convert_ctx;
	int nframe;
	QPixmap pixmap;
	char *rgb_buf;
};

#endif
