#include "cv.h"
#include "highgui.h"
extern "C" {
#include "avcodec.h"
#include "swscale.h"
#include "avformat.h"
}

using namespace std;

class Coder
{
public :
    Coder(int bitRate, int wd, int ht);
	~Coder();
	int get_video_stream(unsigned char* outbuf, unsigned long buf_size);
protected:
	struct SwsContext *img_convert_ctx;
	AVFrame *cv_picture;
	 /*���������뻺��*/
	uint8_t *inbuf;
	 CvCapture* capture;
	 IplImage* cvImage;
	 AVCodec *codec;
     AVCodecContext *codec_context;
	 AVFrame *codec_frame;
};
