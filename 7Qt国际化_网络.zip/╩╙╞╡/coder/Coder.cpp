#include "Coder.h"

Coder::Coder(int bitRate = 400000, int wd = 640, int ht = 480):codec(NULL), codec_context(NULL), codec_frame(NULL),inbuf(NULL)
{
	capture=cvCreateCameraCapture(0);
	int Domain = cvGetCaptureDomain( capture); 
	//��������ʼ��
	avcodec_init();
	avcodec_register_all();
	codec = avcodec_find_encoder(CODEC_ID_MPEG2VIDEO);
	//��������ṹ��
	codec_context = avcodec_alloc_context();
	//��������趨
    /* put sample parameters */
    codec_context->bit_rate = bitRate;
    /* resolution must be a multiple of two */
    codec_context->width = wd;
    codec_context->height = ht;
    /* frames per second */
    codec_context->time_base= (AVRational){1,25};
    codec_context->gop_size = 10; /* emit one intra frame every ten frames */
    codec_context->max_b_frames=1;
    codec_context->pix_fmt = PIX_FMT_YUV420P;
    //����������ͷ��ȡ��RGB24֡�Ľṹ��
	cv_picture = avcodec_alloc_frame();
	//�������������YUV֡�Ľṹ��
	codec_frame = avcodec_alloc_frame();
	//����YUV֡���ڴ�
	int   size = codec_context->width * codec_context->height;
    inbuf =(uint8_t*)new uint8_t[(size * 3) / 2];
	codec_frame->data[0] = (uint8_t *) inbuf;
    codec_frame->data[1] = codec_frame->data[0] + size;
    codec_frame->data[2] = codec_frame->data[1] + size / 4;
    codec_frame->linesize[0] = codec_context->width;
    codec_frame->linesize[1] = codec_context->width / 2;
    codec_frame->linesize[2] = codec_context->width / 2;
    /* �򿪱����� */
    avcodec_open(codec_context, codec);
	//����ͷ��ȡ��RGB֡ת��ΪYUV��ת���ṹ��
	img_convert_ctx = sws_getContext(640, 480, PIX_FMT_BGR24, 
									640, 480, PIX_FMT_YUV420P, SWS_BICUBIC, NULL, NULL, NULL);	
}

Coder::~Coder()
{
    delete []inbuf;
	cvReleaseCapture(&capture);
	av_free(cv_picture);
	av_free(codec_frame);
}

int Coder::get_video_stream(unsigned char* outbuf, unsigned long buf_size)
{
	cvImage = cvQueryFrame( capture );
	//������ͷ��ȡ��������䵽AVFrame�ṹ
	cv_picture->data[0] = (uint8_t *) cvImage->imageData;
	cv_picture->data[1] = NULL;
	cv_picture->data[2] = NULL;
	cv_picture->linesize[0] = cvImage->width * 3;
	cv_picture->linesize[1] = cvImage->width * 3;
	cv_picture->linesize[2] = cvImage->width * 3;
	//RGB24ת����yuv��ɫ�ռ�
	sws_scale(img_convert_ctx, cv_picture->data, cv_picture->linesize, 0, cvImage->height, codec_frame->data, codec_frame->linesize);
	//����
	int outsize = avcodec_encode_video(codec_context, outbuf, buf_size, codec_frame);
	return outsize;
}