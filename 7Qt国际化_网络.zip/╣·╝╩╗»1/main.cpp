#include <QtGui>
#include <QApplication>

int main(int argc, char* argv[])
{
	QApplication app(argc, argv);
	QTranslator trans;
	trans.load("jp_lang");
	app.installTranslator(&trans);
	QPushButton btn(QObject::tr("PUSH ME"));
	btn.show();
	return app.exec();
}