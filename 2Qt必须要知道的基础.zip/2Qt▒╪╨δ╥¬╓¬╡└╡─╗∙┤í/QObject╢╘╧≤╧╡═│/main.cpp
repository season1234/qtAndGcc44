#include <QtCore>
#include <QApplication>
#include <iostream>
using namespace std;

class myObj : public QObject
{
public:
	myObj(QObject* parent):QObject(parent)
	{
		qDebug() << "myObj created !";
	}
	~myObj()
	{
		qDebug() << "myObj destroyed !";
	}
};

int main(int argc, char* argv[])
{
	QCoreApplication app(argc, argv);
	myObj * obf = new myObj;
	//myObj* myob = new myObj(obf);
	QPointer<myObj> ptr = new myObj(obf);
	delete obf;
	cout << ptr;
	return 0;
}