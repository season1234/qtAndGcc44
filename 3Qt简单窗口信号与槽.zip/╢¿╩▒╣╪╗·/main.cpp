#include <QApplication>
#include <QtGui>

class myWin : public QWidget
{
    Q_OBJECT
public:
    myWin(QWidget* parent = 0) : QWidget(parent)
    {
        QVBoxLayout * vlayout = new QVBoxLayout;
        time = new QLabel;
        vlayout->addWidget(time);
        cmd = new QLineEdit;
        vlayout->addWidget(cmd);
        expire = new QTimeEdit;
        vlayout->addWidget(expire);
        lbl = new QLabel;
        vlayout->addWidget(lbl);
        ok = new QPushButton("OK");
        vlayout->addWidget(ok);
        setLayout(vlayout);
        
        time->setText(QTime::currentTime().toString("H:m:s"));
        tmr = new QTimer(this);
        connect(tmr, SIGNAL(timeout()), this, SLOT(Tslot()));
        connect(ok, SIGNAL(clicked()), this, SLOT(btnSlot()));
        tmr->start(1000);
    }
private:
    QLabel* time;
    QLineEdit* cmd;
    QTimeEdit* expire;
    QLabel* lbl;
    QPushButton* ok;
    QTimer* tmr;
    QTime exetime;
    QString program;
    QProcess process;
private slots:
    void btnSlot()
    {
        program = cmd->text();
        exetime = expire->time();
        QString demo = program + '\n' + exetime.toString("H:m:s");
        lbl->setText(demo);
    }
    void Tslot()
    {
       time->setText(QTime::currentTime().toString("H:m:s"));
       if(exetime.toString("H:m:s") == QTime::currentTime().toString("H:m:s"))
       {  
			qDebug() << program;
			process.start(program);
       }    
    }
};

int main(int argc, char* argv[])
{
    QApplication app(argc, argv);
    myWin win;
    win.show();
    return app.exec();
}

#include "main.moc"
