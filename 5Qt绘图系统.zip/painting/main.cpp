#include<QApplication>
#include<QtGui>
#include <QSvgGenerator>

class myWidget : public QWidget
{
	Q_OBJECT
public:
	myWidget(QWidget* parent = 0):QWidget(parent),rect(50, 50,200,50)
	{
		//setAttribute(Qt::WA_MouseTracking);
		//����·������
		//truck.setFillRule(Qt::WindingFill);
		truck.moveTo(0.0, 87.0);
		truck.lineTo(0.0, 60.0);
		truck.lineTo(10.0, 60.0);
		truck.lineTo(35.0, 35.0);
		truck.lineTo(100.0, 35.0);
		truck.lineTo(100.0, 87.0);
		truck.lineTo(0.0, 87.0);
		truck.moveTo(17.0, 60.0);
		truck.lineTo(55.0, 60.0);
		truck.lineTo(55.0, 40.0);
		truck.lineTo(37.0, 40.0);
		truck.lineTo(17.0, 60.0);
		truck.addEllipse(17.0, 75.0, 25.0, 25.0);
		truck.addEllipse(63.0, 75.0, 25.0, 25.0);
		
		path.addRect(20, 20, 60, 60);
		path.moveTo(0, 0);
		path.cubicTo(99, 0,  50, 50,  99, 99);
		path.cubicTo(0, 99,  50, 50,  0, 0);
		
		QPainterPath house;
		house.moveTo(-45.0, -20.0);
		house.lineTo(0.0, -45.0);
		house.lineTo(45.0, -20.0);
		house.lineTo(45.0, 45.0);
		house.lineTo(-45.0, 45.0);
		house.lineTo(-45.0, -20.0);
		house.addRect(15.0, 5.0, 20.0, 35.0);
		house.addRect(-35.0, -15.0, 25.0, 25.0);
		//��QImage�л�ͼ��QImage�Ǵ���ͼƬ��һ���ڴ�
		//ptrImage = new QImage(100, 100, QImage::Format_ARGB32_Premultiplied);
		ptrImage = new QImage("../../qt.png");
		QPainter painter(ptrImage);//or painter.begin(ptrImage);
		painter.setPen(QPen( Qt::blue, 2, Qt::SolidLine,Qt::FlatCap, Qt::MiterJoin));
		painter.translate(100, 100);
		painter.rotate(30);
		painter.drawPath(house);
		
		//��SVG�ļ���ͼ
		QSvgGenerator generator;
		generator.setFileName("../../test.svg");
		generator.setSize(QSize(200, 200));
		generator.setViewBox(QRect(0, 0, 200, 200));
		//generator.setTitle(tr("SVG Generator Example Drawing"));
		//generator.setDescription(tr("An SVG drawing created by the SVG Generator "
        //                        "Example provided with Qt."));
		QPainter painterSVG(&generator);//or painter.begin(ptrImage);
		painterSVG.setPen(QPen( Qt::blue, 2, Qt::SolidLine,Qt::FlatCap, Qt::MiterJoin));
		painterSVG.translate(50, 50);
		painterSVG.rotate(30);
		painterSVG.drawPath(house);
	}
protected:
    void paintEvent(QPaintEvent *event)
	{
		QPainter painter(this);
		painter.setFont(QFont("Times", 30, QFont::Bold, true));
		painter.save ();
		//painter.setPen(Qt::DashLine);
		painter.setPen(QPen(QColor(79, 106, 25), 3, Qt::SolidLine,Qt::FlatCap, Qt::MiterJoin));
		//painter.setBrush(Qt::NoBrush);
		painter.setBrush(QColor(122, 163, 39));
		painter.translate(50, 50);    //�ڻ�ͼ֮ǰ����
		painter.scale(2, 2);    //�ڻ�ͼ֮ǰ����
		painter.rotate(15);
		painter.drawRect(200, 20, 100, 150);
		//painter.setRenderHint(QPainter::Antialiasing);
		//painter.fillPath(truck, Qt::blue);
		painter.drawPath(truck);
		painter.restore();
		painter.drawText(400, 50, "Qt by Nokia");
		painter.drawText(rect, pos);
		
		painter.drawImage( QPoint(400, 150), *ptrImage);
	}
	void mouseMoveEvent(QMouseEvent *event){
		pos = QString("%1, %2").arg(event->pos().x()).arg(event->pos().y());
		update(rect);
	}
private:
	QPainterPath truck;
	QPainterPath path;
	QImage* ptrImage;
	QString pos;
	QRect rect;
};

int main(int argc, char* argv[])
{
	QApplication app(argc, argv);
	myWidget window;
	window.show();
	return app.exec();
	
}

#include "debug/main.moc"