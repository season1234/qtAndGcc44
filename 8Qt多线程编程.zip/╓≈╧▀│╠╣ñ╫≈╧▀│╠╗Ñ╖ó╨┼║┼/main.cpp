﻿#include <QApplication>
#include <QtCore>
#include <QtGui>

class MyThread : public QThread
{
public:
	MyThread(QWidget* win)
	{
		guiWin  = win;
	}
    void run();
protected:
	QWidget* guiWin;
};

void MyThread::run()
{
	QTimer tmr;
	connect(&tmr, SIGNAL(timeout()), guiWin, SLOT(CurrentTime()));
	tmr.start();
	exec();
	qDebug() << "exit event loop";
}

class myWin : public QWidget
{
	Q_OBJECT
public:
	myWin()
	{
		pLbl = new QLabel;
		pBtn = new QPushButton(trUtf8("结束工作线程事件循环"));
		QVBoxLayout* vLayout = new QVBoxLayout;
		vLayout->addWidget(pLbl);
		vLayout->addWidget(pBtn);
		setLayout(vLayout);
		pThread = new MyThread(this);
		connect(pBtn, SIGNAL(clicked()), pThread, SLOT(quit()));
		pThread->start();
	}
private:
	MyThread* pThread;
	QLabel* pLbl;
	QPushButton* pBtn;
public slots:
	void CurrentTime(){
		pLbl->setText(QTime::currentTime().toString());
	}
};

int main(int argc, char* argv[])
{
    QApplication app(argc, argv);
	myWin win;
	win.show();
	return app.exec();
}

#include "main.moc"
