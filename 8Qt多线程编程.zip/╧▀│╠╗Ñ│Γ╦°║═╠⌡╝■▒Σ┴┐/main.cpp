#include <QApplication>
#include <QtCore>
#include <QtGui>
#include <iostream>
using namespace std;

int my_data = 0;

class MyThread : public QThread
{
public:
    MyThread(QMutex* m, QWaitCondition* w)
	{
		lock = m;
		wcon = w;
	}
    void run();
private:
	QMutex* lock;
	QWaitCondition* wcon;
};

void MyThread::run()
{
	while(1)
	{
		lock->lock();
		qDebug() << "Wait for Wait Condition thread " << '['<<QThread::currentThreadId()<<"]";
		wcon->wait(lock);
		my_data--;
		qDebug() << "my_data: " << my_data << "["<<QThread::currentThreadId()<<"]";
		lock->unlock();
	}
}

class myWin : public QWidget
{
	Q_OBJECT
public:
	myWin()
	{
		pEdit = new QLineEdit;
		pBtn = new QPushButton("WakeOne");
		pStart = new QPushButton("Start Thread");
		QVBoxLayout* vLayout = new QVBoxLayout;
		vLayout->addWidget(pEdit);
		vLayout->addWidget(pBtn);
		vLayout->addWidget(pStart);
		setLayout(vLayout);
		connect(pBtn, SIGNAL(clicked()), this, SLOT(CurrentTime()));
		connect(pStart, SIGNAL(clicked()), this, SLOT(StartThread()));
		MLock = new QMutex;
		wcon = new QWaitCondition;
	}
private:
	QLineEdit* pEdit;
	QPushButton* pBtn;
	QPushButton* pStart;
	QMutex* MLock;
	QWaitCondition* wcon;
public slots:
	void CurrentTime(){
		MLock->lock();
		my_data = pEdit->text().toLong();
		wcon->wakeAll();
		MLock->unlock();
	}
	void StartThread()
	{
		MyThread* pThread = new MyThread(MLock, wcon);
		pThread->start();
	}
};

int main(int argc, char* argv[])
{
    QApplication app(argc, argv);
	myWin win;
	win.show();
	return app.exec();
}

#include "main.moc"
