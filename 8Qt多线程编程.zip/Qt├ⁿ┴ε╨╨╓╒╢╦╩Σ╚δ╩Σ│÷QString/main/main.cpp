#include <iostream>
#include <QApplication>
#include <cstdio>
#include <QtCore>
using namespace std;

int main(int argc, char* argv[])
{
    QCoreApplication app(argc, argv);	
	QString yourText; 
	QFile file; 
	file.open(stdin, QIODevice::ReadOnly); 
	QTextStream qtin(&file); 
	qtin >> yourText;
	qDebug() << "Input: " <<yourText;
	return 0;
}