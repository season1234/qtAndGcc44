#include <iostream>
#include <QApplication>
#include <QtGui>

class MenuWidget : public QWidget
{
	Q_OBJECT
public:
	MenuWidget()
	{
		pbar = new QMenuBar(this);
		pMenu = new QMenu("Menu", this);
		pbar->addMenu(pMenu);
		QAction* pAct1 = new QAction(tr("action1"), this);
	    connect(pAct1, SIGNAL(triggered()), this, SLOT(Test1Slot()));
		pMenu->addAction(pAct1);
		QAction* pAct2 = new QAction(tr("action2"), this);
	    connect(pAct2, SIGNAL(triggered()), this, SLOT(Test2Slot()));
		pMenu->addAction(pAct2);
		
		QAction* pAct3 = new QAction(tr("action3"), this);
	    connect(pAct3, SIGNAL(triggered()), this, SLOT(Test3Slot()));
		pMenu->addAction(pAct3);	
		
		pLbl = new QLabel("Hello!", this);
		QVBoxLayout* vLayout = new QVBoxLayout;
		vLayout->addWidget(pbar);
		vLayout->addWidget(pLbl);
		setLayout(vLayout);
	}
protected:
	QMenu* pMenu;
	QLabel* pLbl;
	QMenuBar* pbar;
protected slots:
	void Test1Slot();
	void Test2Slot();
	void Test3Slot();
};

void MenuWidget::Test1Slot()
{
	pLbl->setText("action1 triggered");
}
void MenuWidget::Test2Slot()
{
	pLbl->setText("action2 triggered");
}

void MenuWidget::Test3Slot()
{
	pLbl->setText("action3 triggered");
}

int main(int argc, char* argv[])
{
	QApplication app(argc, argv);
	MenuWidget win;
	win.show();
	return app.exec();
}

#include "main.moc"