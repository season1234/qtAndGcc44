#include <QApplication>
#include <QtGui>

class MyWin : public QWidget
{
	Q_OBJECT
public:
	MyWin(QWidget* parent = 0) : QWidget(parent)
	{
		pBar = new QMenuBar;
		pMFile = new QMenu("File");
		pBar->addMenu(pMFile);
		pLbl = new QLabel;
		QVBoxLayout * vLayout = new QVBoxLayout;
		vLayout->addWidget(pBar);

		setLayout(vLayout);
		
		pANew = new QAction("New", this);
		pMFile->addAction(pANew);
		connect(pANew, SIGNAL(triggered()), this, SLOT(newAct()));
		
		pASave = new QAction("Save", this);
		pMFile->addAction(pASave);
		connect(pASave, SIGNAL(triggered()), this, SLOT(saveAct()));
		
		pMSet = new QMenu("Set");
		pAWinTile = new QAction("winTitle", this);
		pMSet->addAction(pAWinTile);
		connect(pAWinTile, SIGNAL(triggered()), this, SLOT(titleAct()));
		
		pAResize = new QAction("Resize", this);
		pMSet->addAction(pAResize);
		connect(pAResize, SIGNAL(triggered()), this, SLOT(resizeAct()));
		
		pMFile->addMenu(pMSet);
		
		QToolBar* pTlb = new QToolBar;
		vLayout->addWidget(pTlb);
		vLayout->addWidget(pLbl);
		pAWinTile->setIcon(QIcon("icon1.gif"));
		pAResize->setIcon(QIcon("icon2.gif"));
		pTlb->addAction(pAWinTile);
		pTlb->addAction(pAResize);
		pTlb->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);
		
	}
protected:
	void mousePressEvent( QMouseEvent * event );
protected:
	QMenuBar* pBar;
	QMenu* pMFile;
	QMenu* pMSet;
	QLabel* pLbl;
	QAction* pANew;
	QAction* pASave;
	QAction* pAWinTile;
	QAction* pAResize;
protected slots:
	void newAct();
	void saveAct();
	void titleAct();
	void resizeAct();
};

void MyWin::mousePressEvent( QMouseEvent * event )
{
	qDebug() << "mousePressEvent";
	if(event->button() == Qt::RightButton)
		pMFile->popup (event->globalPos());
}

void MyWin::newAct()
{
	pLbl->setText("New Action Triggered");
}

void MyWin::saveAct()
{
	pLbl->setText("Save Action Triggered");
}

void MyWin::titleAct()
{
	//qDebug() << "title Action";
	QString title = QInputDialog::getText(this, "QInputDialog::getText()", "Title:");
	setWindowTitle(title);
}

void MyWin::resizeAct()
{
	int w = QInputDialog::getInt(this, "QInputDialog::getInt()", "width:");
	int h = QInputDialog::getInt(this, "QInputDialog::getInt()", "height:");
	resize(w, h);
}

int main(int argc, char* argv[])
{
	QApplication app(argc, argv);
	MyWin win;
	win.show();
	return app.exec();
}

#include "main.moc"